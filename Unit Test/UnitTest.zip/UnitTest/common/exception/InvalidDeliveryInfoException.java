package common.exception;

public class InvalidDeliveryInfoException {

}
