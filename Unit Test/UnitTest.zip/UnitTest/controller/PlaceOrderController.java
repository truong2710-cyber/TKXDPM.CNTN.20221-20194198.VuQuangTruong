package controller;
import common.exception.InvalidDeliveryInfoException;
import entity.cart.Cart;
import entity.cart.CartMedia;
import entity.invoice.Invoice;
import entity.order.Order;
import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import views.screen.popup.PopupScreen;

/**
 * Place order flow controller
 * @author truong.vq194198
 */
public class PlaceOrderController extends BaseController {

  public void placeOrder() throws SQLException {


  }

  /**
   * This method creates the new Order based on the Cart
   * @return Order
   * @throws SQLException
   */
  public Order createOrder() throws SQLException {
	return null;

  }

  public Invoice createInvoice(Order order) {
	return null;
 
  }

  /**
   * This method takes responsibility for processing the shipping info from user
   * @param info
   * @throws InterruptedException
   * @throws IOException
   */
  public void processDeliveryInfo(HashMap info)
    throws InterruptedException, IOException {
    validateDeliveryInfo(info);
  }

  public void validateDeliveryInfo(HashMap<String, String> info)
		    throws InterruptedException, IOException {}
  
  public boolean validatePhoneNumber(String phoneNumber) {
    	if (phoneNumber == null ||phoneNumber.length() != 10) return false;
        if (!phoneNumber.startsWith("0")) return false;
        
        try {
        	Integer.parseInt(phoneNumber);
        } catch (Exception e) {
			// TODO: handle exception
        	return false;
		}
        return true;
  }
  
  public int calculateShippingFee(Order order) {
    return 0;
  }

  public boolean validateName(String name) {
    if (name == null) {
      return false;
    }
    return name.matches("^[A-Za-z]+$");
  }

  public boolean validateAddress(String address) {
    if (address == null) {
      return false;
    }
    return address.matches("^[A-Za-z0-9]+");
  }
}
