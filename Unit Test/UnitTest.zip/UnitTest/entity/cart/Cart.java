package entity.cart;

public class Cart {

	public static Object getCart() {
		// TODO Auto-generated method stub
		return null;
	}


}
