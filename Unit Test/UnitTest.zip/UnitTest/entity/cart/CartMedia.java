package entity.cart;

public class CartMedia {

}
